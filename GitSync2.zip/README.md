
  # Design GitSync Landing Page

  This is a code bundle for Design GitSync Landing Page. The original project is available at https://www.figma.com/design/7itwjcLy7yqvNA6CCcQ8i0/Design-GitSync-Landing-Page.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  