import { motion } from 'motion/react';
import { Linkedin, Github, Mail, ExternalLink } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { useState } from 'react';
import { Button } from './ui/button';

const teamMembers = [
  {
    name: 'Alex Chen',
    role: 'Co-Founder & CEO',
    image: 'https://images.unsplash.com/photo-1731951039706-0e793240bb32?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBkZXZlbG9wZXIlMjBtYWxlJTIwcG9ydHJhaXR8ZW58MXx8fHwxNzcyOTE3OTU1fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    linkedin: '#',
    github: '#',
    email: 'alex@gitsync.com',
  },
  {
    name: 'Sarah Johnson',
    role: 'CTO',
    image: 'https://images.unsplash.com/photo-1686051462211-20a1ccc5ac56?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBkZXZlbG9wZXIlMjBmZW1hbGUlMjBwb3J0cmFpdHxlbnwxfHx8fDE3NzI5MTc5NTV8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    linkedin: '#',
    github: '#',
    email: 'sarah@gitsync.com',
  },
  {
    name: 'Marcus Rodriguez',
    role: 'Lead Engineer',
    image: 'https://images.unsplash.com/photo-1660074127797-1c429fbb8cd6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBlbmdpbmVlciUyMG1hbGUlMjBwb3J0cmFpdHxlbnwxfHx8fDE3NzI4MTg0MDR8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    linkedin: '#',
    github: '#',
    email: 'marcus@gitsync.com',
  },
  {
    name: 'Emily Zhang',
    role: 'Product Designer',
    image: 'https://images.unsplash.com/photo-1712174766230-cb7304feaafe?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjB0ZWNoJTIwd29tYW4lMjBwb3J0cmFpdHxlbnwxfHx8fDE3NzI5MTc5NTZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    linkedin: '#',
    github: '#',
    email: 'emily@gitsync.com',
  },
];

function TeamMemberCard({ member, index }: { member: typeof teamMembers[0], index: number }) {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.6, delay: index * 0.1 }}
      whileHover={{ y: -8 }}
      onHoverStart={() => setIsHovered(true)}
      onHoverEnd={() => setIsHovered(false)}
      className="bg-white rounded-2xl overflow-hidden shadow-lg border border-gray-100 hover:shadow-xl transition-all group relative"
    >
      <div className="relative overflow-hidden aspect-square">
        <ImageWithFallback
          src={member.image}
          alt={member.name}
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0B1F3A]/90 via-[#0B1F3A]/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
        
        {/* Hover Actions Overlay */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{
            opacity: isHovered ? 1 : 0,
            y: isHovered ? 0 : 20,
          }}
          className="absolute inset-0 flex items-center justify-center p-6"
        >
          <div className="space-y-2 w-full">
            <Button className="w-full bg-white hover:bg-gray-100 text-[#0B1F3A]">
              <Mail className="w-4 h-4 mr-2" />
              Contact
            </Button>
            <Button className="w-full bg-[#3A7BFF] hover:bg-[#2D6BE8] text-white">
              <ExternalLink className="w-4 h-4 mr-2" />
              View Profile
            </Button>
          </div>
        </motion.div>
      </div>
      <div className="p-6">
        <h3 className="text-xl font-semibold text-[#0B1F3A] mb-2">
          {member.name}
        </h3>
        <p className="text-gray-600 mb-4">{member.role}</p>
        <div className="flex gap-3">
          <a
            href={member.linkedin}
            className="w-10 h-10 bg-blue-50 rounded-lg flex items-center justify-center hover:bg-[#3A7BFF] hover:text-white transition-colors"
          >
            <Linkedin className="w-5 h-5" />
          </a>
          <a
            href={member.github}
            className="w-10 h-10 bg-blue-50 rounded-lg flex items-center justify-center hover:bg-[#3A7BFF] hover:text-white transition-colors"
          >
            <Github className="w-5 h-5" />
          </a>
          <a
            href={`mailto:${member.email}`}
            className="w-10 h-10 bg-blue-50 rounded-lg flex items-center justify-center hover:bg-[#3A7BFF] hover:text-white transition-colors"
          >
            <Mail className="w-5 h-5" />
          </a>
        </div>
      </div>
    </motion.div>
  );
}

export function TeamSection() {
  return (
    <section id="team" className="py-24 px-6 bg-white">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl lg:text-5xl font-bold text-[#0B1F3A] mb-4">
            Meet the Team
          </h2>
          <p className="text-gray-600 mt-4">Hover to connect with our team members</p>
        </motion.div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {teamMembers.map((member, index) => (
            <TeamMemberCard key={index} member={member} index={index} />
          ))}
        </div>
      </div>
    </section>
  );
}
