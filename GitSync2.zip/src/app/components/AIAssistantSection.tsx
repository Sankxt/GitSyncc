import { motion } from 'motion/react';
import { Send, Bot, Code2, CheckCircle, Loader2, Sparkles } from 'lucide-react';
import { useState } from 'react';
import { Button } from './ui/button';

interface Message {
  role: 'user' | 'assistant';
  content: string;
  status?: 'pending' | 'completed' | 'error';
}

export function AIAssistantSection() {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: 'assistant',
      content: 'Hi! I\'m your GitSync AI Assistant. Tell me what code changes you need, and I\'ll handle the Git operations automatically. For example: "Add a login button to the navbar" or "Fix the authentication bug in user.js"',
    },
  ]);
  const [input, setInput] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isProcessing) return;

    const userMessage = input;
    setInput('');
    
    // Add user message
    setMessages(prev => [...prev, { role: 'user', content: userMessage }]);
    setIsProcessing(true);

    // Simulate AI processing
    setTimeout(() => {
      setMessages(prev => [
        ...prev,
        {
          role: 'assistant',
          content: '🔍 Analyzing your request...',
          status: 'pending',
        },
      ]);
    }, 500);

    setTimeout(() => {
      setMessages(prev => {
        const newMessages = [...prev];
        newMessages[newMessages.length - 1] = {
          role: 'assistant',
          content: '✨ Generating code changes...',
          status: 'pending',
        };
        return newMessages;
      });
    }, 1500);

    setTimeout(() => {
      setMessages(prev => {
        const newMessages = [...prev];
        newMessages[newMessages.length - 1] = {
          role: 'assistant',
          content: '📝 Committing changes to repository...',
          status: 'pending',
        };
        return newMessages;
      });
    }, 3000);

    setTimeout(() => {
      setMessages(prev => {
        const newMessages = [...prev];
        newMessages[newMessages.length - 1] = {
          role: 'assistant',
          content: '🚀 Pushing to remote repository...',
          status: 'pending',
        };
        return newMessages;
      });
    }, 4500);

    setTimeout(() => {
      setMessages(prev => {
        const newMessages = [...prev];
        newMessages[newMessages.length - 1] = {
          role: 'assistant',
          content: `✅ Successfully completed! I've made the changes for: "${userMessage}"\n\nChanges pushed to: main branch\nCommit: feat: ${userMessage.toLowerCase()}\nFiles modified: 3 files\nLines added: +42 lines\n\nYour team has been notified and the changes are now live.`,
          status: 'completed',
        };
        return newMessages;
      });
      setIsProcessing(false);
    }, 6000);
  };

  return (
    <section className="py-24 px-6 bg-gradient-to-br from-[#0B1F3A] via-[#1a3a5c] to-[#0B1F3A] text-white">
      <div className="max-w-5xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <div className="inline-flex items-center gap-2 bg-white/10 px-4 py-2 rounded-full mb-4">
            <Sparkles className="w-4 h-4 text-[#3A7BFF]" />
            <span className="text-sm">Powered by AI</span>
          </div>
          <h2 className="text-4xl lg:text-5xl font-bold mb-4">
            AI-Powered Code Push Assistant
          </h2>
          <p className="text-gray-300 text-lg">
            Tell our AI what to do, and it will automatically write, commit, and push code for you
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="bg-white rounded-2xl shadow-2xl overflow-hidden"
        >
          {/* Chat Header */}
          <div className="bg-gradient-to-r from-[#3A7BFF] to-[#2D6BE8] p-4 flex items-center gap-3">
            <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
              <Bot className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="font-semibold text-white">GitSync AI Assistant</h3>
              <p className="text-xs text-white/80">Always ready to help</p>
            </div>
            <div className="ml-auto flex items-center gap-2">
              <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
              <span className="text-xs text-white/80">Online</span>
            </div>
          </div>

          {/* Chat Messages */}
          <div className="h-[500px] overflow-y-auto p-6 bg-gray-50 space-y-4">
            {messages.map((message, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
                className={`flex gap-3 ${message.role === 'user' ? 'flex-row-reverse' : ''}`}
              >
                <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                  message.role === 'user' ? 'bg-[#3A7BFF]' : 'bg-gradient-to-br from-purple-500 to-pink-500'
                }`}>
                  {message.role === 'user' ? (
                    <span className="text-white text-sm font-semibold">You</span>
                  ) : (
                    <Bot className="w-5 h-5 text-white" />
                  )}
                </div>
                <div className={`max-w-[80%] rounded-2xl p-4 ${
                  message.role === 'user'
                    ? 'bg-[#3A7BFF] text-white'
                    : 'bg-white text-gray-800 shadow-sm border border-gray-200'
                }`}>
                  <p className="text-sm leading-relaxed whitespace-pre-line">{message.content}</p>
                  {message.status === 'pending' && (
                    <Loader2 className="w-4 h-4 mt-2 animate-spin text-[#3A7BFF]" />
                  )}
                  {message.status === 'completed' && (
                    <div className="mt-3 flex items-center gap-2 text-green-600">
                      <CheckCircle className="w-4 h-4" />
                      <span className="text-xs font-medium">Completed</span>
                    </div>
                  )}
                </div>
              </motion.div>
            ))}
          </div>

          {/* Chat Input */}
          <form onSubmit={handleSubmit} className="p-4 bg-white border-t border-gray-200">
            <div className="flex gap-3">
              <div className="flex-1 relative">
                <Code2 className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder="E.g., 'Add error handling to the login function' or 'Update the CSS for the header'"
                  className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#3A7BFF] text-gray-800"
                  disabled={isProcessing}
                />
              </div>
              <Button
                type="submit"
                disabled={!input.trim() || isProcessing}
                className="bg-[#3A7BFF] hover:bg-[#2D6BE8] text-white px-6 disabled:opacity-50"
              >
                {isProcessing ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : (
                  <>
                    <Send className="w-5 h-5 mr-2" />
                    Push
                  </>
                )}
              </Button>
            </div>
            <div className="mt-2 flex gap-2 flex-wrap">
              <button
                type="button"
                onClick={() => setInput('Add a new dark mode toggle button')}
                className="text-xs px-3 py-1 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-full transition-colors"
                disabled={isProcessing}
              >
                Add dark mode toggle
              </button>
              <button
                type="button"
                onClick={() => setInput('Fix the responsive layout on mobile')}
                className="text-xs px-3 py-1 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-full transition-colors"
                disabled={isProcessing}
              >
                Fix mobile layout
              </button>
              <button
                type="button"
                onClick={() => setInput('Optimize database queries in API')}
                className="text-xs px-3 py-1 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-full transition-colors"
                disabled={isProcessing}
              >
                Optimize queries
              </button>
            </div>
          </form>
        </motion.div>

        {/* Info Cards */}
        <div className="grid md:grid-cols-3 gap-6 mt-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20"
          >
            <Code2 className="w-8 h-8 text-[#3A7BFF] mb-3" />
            <h4 className="font-semibold mb-2">Natural Language</h4>
            <p className="text-sm text-gray-300">Describe changes in plain English, no technical commands needed</p>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20"
          >
            <CheckCircle className="w-8 h-8 text-[#3A7BFF] mb-3" />
            <h4 className="font-semibold mb-2">Automated Workflow</h4>
            <p className="text-sm text-gray-300">AI handles writing, testing, committing, and pushing automatically</p>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.5 }}
            className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20"
          >
            <Sparkles className="w-8 h-8 text-[#3A7BFF] mb-3" />
            <h4 className="font-semibold mb-2">Smart Integration</h4>
            <p className="text-sm text-gray-300">Seamlessly integrates with your existing Git workflow and CI/CD</p>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
