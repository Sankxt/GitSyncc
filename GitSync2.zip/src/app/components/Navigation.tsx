import { GitBranch, Moon, Sun } from 'lucide-react';
import { Button } from './ui/button';
import { useTheme } from './ThemeProvider';

export function Navigation() {
  const { theme, toggleTheme } = useTheme();

  return (
    <nav className="sticky top-0 z-50 w-full bg-white dark:bg-[#0B1F3A] border-b border-gray-200 dark:border-gray-700 transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <div className="flex items-center gap-2">
            <GitBranch className="w-6 h-6 text-[#3A7BFF]" />
            <span className="text-xl font-bold text-[#0B1F3A] dark:text-white">GitSync</span>
          </div>

          {/* Navigation Menu */}
          <div className="hidden md:flex items-center gap-8">
            <a href="#features" className="text-[#0B1F3A] dark:text-gray-300 hover:text-[#3A7BFF] dark:hover:text-[#3A7BFF] transition-colors">
              Features
            </a>
            <a href="#how-it-works" className="text-[#0B1F3A] dark:text-gray-300 hover:text-[#3A7BFF] dark:hover:text-[#3A7BFF] transition-colors">
              How It Works
            </a>
            <a href="#docs" className="text-[#0B1F3A] dark:text-gray-300 hover:text-[#3A7BFF] dark:hover:text-[#3A7BFF] transition-colors">
              Docs
            </a>
          </div>

          {/* Buttons */}
          <div className="flex items-center gap-4">
            {/* Theme Toggle */}
            <Button
              variant="ghost"
              size="icon"
              onClick={toggleTheme}
              className="text-[#0B1F3A] dark:text-gray-300 hover:text-[#3A7BFF] dark:hover:text-[#3A7BFF]"
            >
              {theme === 'light' ? (
                <Moon className="w-5 h-5" />
              ) : (
                <Sun className="w-5 h-5" />
              )}
            </Button>
            <Button variant="ghost" className="text-[#0B1F3A] dark:text-gray-300">
              Login
            </Button>
            <Button className="bg-[#3A7BFF] hover:bg-[#2D6BE8] text-white">
              Connect Repo
            </Button>
          </div>
        </div>
      </div>
    </nav>
  );
}
