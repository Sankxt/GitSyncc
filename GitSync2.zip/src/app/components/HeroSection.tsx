import { motion } from 'motion/react';
import { Button } from './ui/button';
import { GitBranch, GitMerge, ArrowRight, CheckCircle, Github, Play, Sparkles } from 'lucide-react';
import { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from './ui/dialog';

export function HeroSection() {
  const [showGithubLogin, setShowGithubLogin] = useState(false);
  const [showDemo, setShowDemo] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);

  const handleGithubLogin = () => {
    setIsConnecting(true);
    // Simulate GitHub OAuth flow
    setTimeout(() => {
      setIsConnecting(false);
      setShowGithubLogin(false);
      alert('Successfully connected to GitHub!');
    }, 2000);
  };

  return (
    <section className="relative overflow-hidden bg-gradient-to-br from-white via-blue-50 to-white dark:from-[#0B1F3A] dark:via-[#1a3a5c] dark:to-[#0B1F3A] py-24 px-6 transition-colors duration-300">
      <div className="max-w-7xl mx-auto">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left Side - Text */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="text-5xl lg:text-6xl font-bold text-[#0B1F3A] dark:text-white mb-6 leading-tight">
              Automate Git Collaboration with Intelligent Merging
            </h1>
            <p className="text-lg text-gray-600 dark:text-gray-300 mb-8 leading-relaxed">
              GitSync helps development teams collaborate faster by automatically syncing repositories, 
              monitoring team activity, and resolving merge conflicts with AI assistance.
            </p>
            <div className="flex flex-wrap gap-4 mb-8">
              <Button 
                onClick={() => setShowGithubLogin(true)}
                className="bg-[#3A7BFF] hover:bg-[#2D6BE8] text-white text-lg px-8 py-6"
              >
                <Github className="mr-2 w-5 h-5" />
                Login with GitHub
              </Button>
              <Button 
                onClick={() => setShowDemo(true)}
                variant="outline" 
                className="border-2 border-[#0B1F3A] dark:border-white text-[#0B1F3A] dark:text-white dark:bg-transparent text-lg px-8 py-6 hover:bg-[#0B1F3A] hover:text-white dark:hover:bg-white dark:hover:text-[#0B1F3A]"
              >
                <Play className="mr-2 w-5 h-5" />
                View Demo
              </Button>
            </div>
            <Button 
              variant="ghost" 
              className="text-[#3A7BFF] hover:text-[#2D6BE8] dark:text-[#3A7BFF] dark:hover:text-[#5A9BFF]"
            >
              View Documentation
              <ArrowRight className="ml-2 w-4 h-4" />
            </Button>
          </motion.div>

          {/* Right Side - Dashboard Illustration */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="relative"
          >
            <div className="relative">
              {/* Main Dashboard Card */}
              <motion.div
                animate={{ y: [0, -10, 0] }}
                transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
                className="bg-white dark:bg-[#1a3a5c] rounded-2xl shadow-2xl p-6 border border-gray-200 dark:border-gray-700 transition-colors duration-300"
              >
                <div className="flex items-center justify-between mb-6">
                  <h3 className="font-semibold text-[#0B1F3A] dark:text-white">Repository Activity</h3>
                  <div className="flex items-center gap-2 text-green-600 dark:text-green-400">
                    <div className="w-2 h-2 bg-green-600 dark:bg-green-400 rounded-full animate-pulse"></div>
                    <span className="text-sm">Live</span>
                  </div>
                </div>
                
                {/* Git Branch Visualization */}
                <div className="space-y-4">
                  <div className="flex items-center gap-3 p-3 bg-blue-50 dark:bg-[#0B1F3A] rounded-lg">
                    <GitBranch className="w-5 h-5 text-[#3A7BFF]" />
                    <div className="flex-1">
                      <div className="text-sm font-medium text-[#0B1F3A] dark:text-white">feature/auth-system</div>
                      <div className="text-xs text-gray-500 dark:text-gray-400">2 commits ahead</div>
                    </div>
                    <CheckCircle className="w-5 h-5 text-green-600 dark:text-green-400" />
                  </div>
                  
                  <div className="flex items-center gap-3 p-3 bg-blue-50 dark:bg-[#0B1F3A] rounded-lg">
                    <GitMerge className="w-5 h-5 text-[#3A7BFF]" />
                    <div className="flex-1">
                      <div className="text-sm font-medium text-[#0B1F3A] dark:text-white">Auto-merge: main ← develop</div>
                      <div className="text-xs text-gray-500 dark:text-gray-400">AI resolving conflicts...</div>
                    </div>
                    <div className="w-5 h-5 border-2 border-[#3A7BFF] border-t-transparent rounded-full animate-spin"></div>
                  </div>
                  
                  <div className="flex items-center gap-3 p-3 bg-green-50 dark:bg-green-900/30 rounded-lg">
                    <GitBranch className="w-5 h-5 text-green-600 dark:text-green-400" />
                    <div className="flex-1">
                      <div className="text-sm font-medium text-[#0B1F3A] dark:text-white">hotfix/security-patch</div>
                      <div className="text-xs text-gray-500 dark:text-gray-400">Synced successfully</div>
                    </div>
                    <CheckCircle className="w-5 h-5 text-green-600 dark:text-green-400" />
                  </div>
                </div>
              </motion.div>

              {/* Floating Card 1 */}
              <motion.div
                animate={{ y: [0, -15, 0], x: [0, 5, 0] }}
                transition={{ duration: 4, repeat: Infinity, ease: "easeInOut", delay: 0.5 }}
                className="absolute -top-4 -right-4 bg-white dark:bg-[#1a3a5c] rounded-xl shadow-lg p-4 border border-gray-200 dark:border-gray-700"
              >
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 bg-green-100 dark:bg-green-900/30 rounded-full flex items-center justify-center">
                    <CheckCircle className="w-5 h-5 text-green-600 dark:text-green-400" />
                  </div>
                  <div>
                    <div className="text-xs font-medium text-[#0B1F3A] dark:text-white">24 Conflicts</div>
                    <div className="text-xs text-gray-500 dark:text-gray-400">Auto-Resolved</div>
                  </div>
                </div>
              </motion.div>

              {/* Floating Card 2 */}
              <motion.div
                animate={{ y: [0, 15, 0], x: [0, -5, 0] }}
                transition={{ duration: 3.5, repeat: Infinity, ease: "easeInOut", delay: 0.3 }}
                className="absolute -bottom-4 -left-4 bg-white dark:bg-[#1a3a5c] rounded-xl shadow-lg p-4 border border-gray-200 dark:border-gray-700"
              >
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 bg-blue-100 dark:bg-blue-900/30 rounded-full flex items-center justify-center">
                    <GitBranch className="w-5 h-5 text-[#3A7BFF]" />
                  </div>
                  <div>
                    <div className="text-xs font-medium text-[#0B1F3A] dark:text-white">156 Commits</div>
                    <div className="text-xs text-gray-500 dark:text-gray-400">This Week</div>
                  </div>
                </div>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </div>

      {/* GitHub Login Dialog */}
      <Dialog open={showGithubLogin} onOpenChange={setShowGithubLogin}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Github className="w-6 h-6" />
              Connect with GitHub
            </DialogTitle>
            <DialogDescription>
              Securely connect your GitHub account to start syncing repositories
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-6 py-4">
            <div className="bg-blue-50 rounded-lg p-4">
              <h4 className="font-semibold text-[#0B1F3A] mb-2">What you'll get:</h4>
              <ul className="space-y-2 text-sm text-gray-600">
                <li className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-green-600" />
                  Automatic repository synchronization
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-green-600" />
                  AI-powered merge conflict resolution
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-green-600" />
                  Real-time team activity monitoring
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-green-600" />
                  Automated code push with AI assistant
                </li>
              </ul>
            </div>

            <div className="space-y-3">
              <Button
                onClick={handleGithubLogin}
                disabled={isConnecting}
                className="w-full bg-[#24292e] hover:bg-[#1b1f23] text-white py-6"
              >
                {isConnecting ? (
                  <>
                    <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                    Connecting...
                  </>
                ) : (
                  <>
                    <Github className="w-5 h-5 mr-2" />
                    Continue with GitHub
                  </>
                )}
              </Button>
              <p className="text-xs text-center text-gray-500">
                By connecting, you agree to our Terms of Service and Privacy Policy
              </p>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Demo Dialog */}
      <Dialog open={showDemo} onOpenChange={setShowDemo}>
        <DialogContent className="sm:max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Play className="w-6 h-6 text-[#3A7BFF]" />
              GitSync Demo - How It Works
            </DialogTitle>
            <DialogDescription>
              See how GitSync automates your Git workflow in action
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-6 py-4">
            {/* Video Placeholder */}
            <div className="relative bg-gradient-to-br from-[#0B1F3A] to-[#1a3a5c] rounded-xl aspect-video flex items-center justify-center overflow-hidden">
              <motion.div
                animate={{ scale: [1, 1.05, 1] }}
                transition={{ duration: 2, repeat: Infinity }}
                className="absolute inset-0 bg-gradient-to-br from-[#3A7BFF]/20 to-transparent"
              ></motion.div>
              <div className="relative z-10 text-center">
                <div className="w-20 h-20 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center mx-auto mb-4">
                  <Play className="w-10 h-10 text-white ml-1" />
                </div>
                <p className="text-white text-lg font-semibold">Demo Video</p>
                <p className="text-white/70 text-sm">Click to watch full demo</p>
              </div>
            </div>

            {/* Demo Steps */}
            <div className="space-y-4">
              <h4 className="font-semibold text-[#0B1F3A]">Quick Demo Overview:</h4>
              
              <div className="grid md:grid-cols-2 gap-4">
                <div className="bg-white border border-gray-200 rounded-lg p-4">
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                      <span className="text-[#3A7BFF] font-bold">1</span>
                    </div>
                    <div>
                      <h5 className="font-semibold text-[#0B1F3A] mb-1">Connect Repository</h5>
                      <p className="text-sm text-gray-600">Login with GitHub and select your repository in seconds</p>
                    </div>
                  </div>
                </div>

                <div className="bg-white border border-gray-200 rounded-lg p-4">
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                      <span className="text-[#3A7BFF] font-bold">2</span>
                    </div>
                    <div>
                      <h5 className="font-semibold text-[#0B1F3A] mb-1">Auto Sync Active</h5>
                      <p className="text-sm text-gray-600">GitSync monitors all changes and syncs automatically</p>
                    </div>
                  </div>
                </div>

                <div className="bg-white border border-gray-200 rounded-lg p-4">
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                      <span className="text-[#3A7BFF] font-bold">3</span>
                    </div>
                    <div>
                      <h5 className="font-semibold text-[#0B1F3A] mb-1">AI Resolves Conflicts</h5>
                      <p className="text-sm text-gray-600">Watch AI automatically detect and resolve merge conflicts</p>
                    </div>
                  </div>
                </div>

                <div className="bg-white border border-gray-200 rounded-lg p-4">
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                      <span className="text-[#3A7BFF] font-bold">4</span>
                    </div>
                    <div>
                      <h5 className="font-semibold text-[#0B1F3A] mb-1">AI Assistant Push</h5>
                      <p className="text-sm text-gray-600">Tell AI what to code and it pushes changes automatically</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Interactive Demo */}
            <div className="bg-gradient-to-br from-blue-50 to-white rounded-xl p-6 border border-blue-200">
              <h4 className="font-semibold text-[#0B1F3A] mb-4 flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-[#3A7BFF]" />
                Try Interactive Demo
              </h4>
              <div className="space-y-3">
                <div className="bg-white rounded-lg p-4 border border-gray-200">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                      <CheckCircle className="w-6 h-6 text-green-600" />
                    </div>
                    <div className="flex-1">
                      <div className="text-sm font-medium text-[#0B1F3A]">Repository: demo-project</div>
                      <div className="text-xs text-gray-500">Status: Connected & Syncing</div>
                    </div>
                    <div className="text-xs bg-green-100 text-green-700 px-2 py-1 rounded-full">Live</div>
                  </div>
                </div>
                <Button
                  onClick={() => {
                    setShowDemo(false);
                    setShowGithubLogin(true);
                  }}
                  className="w-full bg-[#3A7BFF] hover:bg-[#2D6BE8] text-white"
                >
                  Start Using GitSync Now
                  <ArrowRight className="ml-2 w-4 h-4" />
                </Button>
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </section>
  );
}