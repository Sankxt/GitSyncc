import { motion } from 'motion/react';
import { RefreshCw, Activity, Sparkles, GitMerge, Settings } from 'lucide-react';
import { Button } from './ui/button';
import { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from './ui/dialog';

const features = [
  {
    icon: RefreshCw,
    title: 'Automatic Repository Sync',
    description: 'Automatically sync repositories and keep all team members updated with the latest commits.',
  },
  {
    icon: Activity,
    title: 'Real-Time Team Activity',
    description: 'Track commits, pull requests, and team activity across repositories instantly.',
  },
  {
    icon: Sparkles,
    title: 'AI Conflict Assistance',
    description: 'Resolve merge conflicts faster with intelligent AI suggestions and automated fixes.',
  },
];

function FeatureCard({ feature, index }: { feature: typeof features[0], index: number }) {
  const [isHovered, setIsHovered] = useState(false);
  const [autoSync, setAutoSync] = useState(false);
  const [autoMerge, setAutoMerge] = useState(false);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.6, delay: index * 0.1 }}
      whileHover={{ y: -8 }}
      onHoverStart={() => setIsHovered(true)}
      onHoverEnd={() => setIsHovered(false)}
      className="bg-white rounded-2xl p-8 shadow-lg border border-gray-100 hover:shadow-xl transition-all relative overflow-hidden group"
    >
      {/* Hover Actions Overlay */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: isHovered ? 1 : 0, y: isHovered ? 0 : 20 }}
        className="absolute inset-0 bg-gradient-to-br from-[#3A7BFF]/95 to-[#0B1F3A]/95 flex flex-col items-center justify-center gap-4 p-6 z-10"
      >
        <div className="flex flex-col gap-3 w-full">
          <Button
            onClick={() => setAutoSync(!autoSync)}
            className={`w-full ${autoSync ? 'bg-green-500 hover:bg-green-600' : 'bg-white hover:bg-gray-100'} ${autoSync ? 'text-white' : 'text-[#0B1F3A]'}`}
          >
            <RefreshCw className="w-4 h-4 mr-2" />
            {autoSync ? 'Auto Sync Enabled' : 'Enable Auto Sync'}
          </Button>
          <Button
            onClick={() => setAutoMerge(!autoMerge)}
            className={`w-full ${autoMerge ? 'bg-green-500 hover:bg-green-600' : 'bg-white hover:bg-gray-100'} ${autoMerge ? 'text-white' : 'text-[#0B1F3A]'}`}
          >
            <GitMerge className="w-4 h-4 mr-2" />
            {autoMerge ? 'Auto Merge Enabled' : 'Enable Auto Merge'}
          </Button>
          <Dialog>
            <DialogTrigger asChild>
              <Button className="w-full bg-white hover:bg-gray-100 text-[#0B1F3A]">
                <Settings className="w-4 h-4 mr-2" />
                Configure Settings
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>{feature.title} Settings</DialogTitle>
                <DialogDescription>
                  Configure your {feature.title.toLowerCase()} preferences.
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="flex items-center justify-between">
                  <label className="text-sm font-medium">Auto Sync</label>
                  <button
                    onClick={() => setAutoSync(!autoSync)}
                    className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${autoSync ? 'bg-[#3A7BFF]' : 'bg-gray-200'}`}
                  >
                    <span className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${autoSync ? 'translate-x-6' : 'translate-x-1'}`} />
                  </button>
                </div>
                <div className="flex items-center justify-between">
                  <label className="text-sm font-medium">Auto Merge</label>
                  <button
                    onClick={() => setAutoMerge(!autoMerge)}
                    className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${autoMerge ? 'bg-[#3A7BFF]' : 'bg-gray-200'}`}
                  >
                    <span className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${autoMerge ? 'translate-x-6' : 'translate-x-1'}`} />
                  </button>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Sync Interval</label>
                  <select className="w-full p-2 border rounded-lg">
                    <option>Every 5 minutes</option>
                    <option>Every 15 minutes</option>
                    <option>Every 30 minutes</option>
                    <option>Every hour</option>
                  </select>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </motion.div>

      {/* Original Card Content */}
      <div className="w-14 h-14 bg-blue-100 dark:bg-blue-900/30 rounded-xl flex items-center justify-center mb-6">
        <feature.icon className="w-7 h-7 text-[#3A7BFF]" />
      </div>
      <h3 className="text-xl font-semibold text-[#0B1F3A] dark:text-white mb-4">
        {feature.title}
      </h3>
      <p className="text-gray-600 dark:text-gray-300 leading-relaxed">
        {feature.description}
      </p>
      
      {/* Status Indicators */}
      <div className="mt-4 flex gap-2">
        {autoSync && (
          <span className="text-xs bg-green-100 text-green-700 px-2 py-1 rounded-full">
            Auto Sync ON
          </span>
        )}
        {autoMerge && (
          <span className="text-xs bg-green-100 text-green-700 px-2 py-1 rounded-full">
            Auto Merge ON
          </span>
        )}
      </div>
    </motion.div>
  );
}

export function FeaturesSection() {
  return (
    <section id="features" className="py-24 px-6 bg-white dark:bg-[#0f2744] transition-colors duration-300">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl lg:text-5xl font-bold text-[#0B1F3A] dark:text-white mb-4">
            Powerful Features for Seamless Collaboration
          </h2>
          <p className="text-gray-600 dark:text-gray-300 mt-4">Hover over each feature to enable auto sync and merge options</p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <FeatureCard key={index} feature={feature} index={index} />
          ))}
        </div>
      </div>
    </section>
  );
}