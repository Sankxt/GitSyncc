import { motion } from 'motion/react';
import { LogIn, FolderGit2, Code2, ArrowRight, Settings, Play, GitMerge } from 'lucide-react';
import { useState } from 'react';
import { Button } from './ui/button';

const steps = [
  {
    icon: LogIn,
    step: 'Step 1',
    title: 'Login with GitSync',
    description: 'Securely authenticate and connect your Git account.',
    action: 'Connect Now',
  },
  {
    icon: FolderGit2,
    step: 'Step 2',
    title: 'Select a Repository',
    description: 'Choose the repository you want GitSync to monitor and synchronize.',
    action: 'Browse Repos',
  },
  {
    icon: Code2,
    step: 'Step 3',
    title: 'Push Code Normally',
    description: 'Developers continue pushing code as usual while GitSync automatically syncs repositories and resolves conflicts intelligently.',
    action: 'Start Coding',
  },
  {
    icon: GitMerge,
    step: 'Step 4',
    title: 'Auto Sync and Merge',
    description: 'GitSync automatically syncs all changes across your team and intelligently merges branches without manual intervention.',
    action: 'Enable Auto Sync',
  },
];

function StepCard({ step, index }: { step: typeof steps[0], index: number }) {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <div className="relative">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        whileInView={{ opacity: 1, scale: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6, delay: index * 0.2 }}
        onHoverStart={() => setIsHovered(true)}
        onHoverEnd={() => setIsHovered(false)}
        className="relative"
      >
        {/* Connecting Arrow */}
        {index < steps.length - 1 && (
          <div className="hidden md:block absolute top-16 -right-4 z-0">
            <ArrowRight className="w-8 h-8 text-[#3A7BFF]" />
          </div>
        )}

        {/* Step Card */}
        <div className="bg-white dark:bg-[#1a3a5c] rounded-2xl p-8 shadow-lg border border-gray-100 dark:border-gray-700 text-center relative z-10 hover:shadow-2xl transition-all">
          <div className="w-16 h-16 bg-gradient-to-br from-[#3A7BFF] to-[#2D6BE8] rounded-2xl flex items-center justify-center mx-auto mb-6">
            <step.icon className="w-8 h-8 text-white" />
          </div>
          <div className="text-sm font-semibold text-[#3A7BFF] mb-2">
            {step.step}
          </div>
          <h3 className="text-xl font-semibold text-[#0B1F3A] dark:text-white mb-4">
            {step.title}
          </h3>
          <p className="text-gray-600 dark:text-gray-300 leading-relaxed mb-6">
            {step.description}
          </p>

          {/* Hover Actions */}
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{
              opacity: isHovered ? 1 : 0,
              height: isHovered ? 'auto' : 0,
            }}
            className="overflow-hidden"
          >
            <div className="space-y-2 pt-4 border-t border-gray-200">
              <Button className="w-full bg-[#3A7BFF] hover:bg-[#2D6BE8] text-white">
                <Play className="w-4 h-4 mr-2" />
                {step.action}
              </Button>
              <Button variant="outline" className="w-full border-[#3A7BFF] text-[#3A7BFF]">
                <Settings className="w-4 h-4 mr-2" />
                Configure
              </Button>
            </div>
          </motion.div>
        </div>
      </motion.div>
    </div>
  );
}

export function HowItWorksSection() {
  return (
    <section id="how-it-works" className="py-24 px-6 bg-gradient-to-br from-blue-50 via-white to-blue-50 dark:from-[#0B1F3A] dark:via-[#0f2744] dark:to-[#0B1F3A] transition-colors duration-300">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl lg:text-5xl font-bold text-[#0B1F3A] dark:text-white mb-4">
            How GitSync Works
          </h2>
          <p className="text-gray-600 dark:text-gray-300 mt-4">Hover over each step to see available actions</p>
        </motion.div>

        <div className="grid md:grid-cols-4 gap-8 items-start relative">
          {steps.map((step, index) => (
            <StepCard key={index} step={step} index={index} />
          ))}
        </div>
      </div>
    </section>
  );
}