import { ThemeProvider } from './components/ThemeProvider';
import { Navigation } from './components/Navigation';
import { HeroSection } from './components/HeroSection';
import { FeaturesSection } from './components/FeaturesSection';
import { HowItWorksSection } from './components/HowItWorksSection';
import { AIAssistantSection } from './components/AIAssistantSection';
import { Footer } from './components/Footer';

export default function App() {
  return (
    <ThemeProvider>
      <div className="min-h-screen bg-white dark:bg-[#0B1F3A] transition-colors duration-300 font-['Inter']">
        <Navigation />
        <HeroSection />
        <FeaturesSection />
        <HowItWorksSection />
        <AIAssistantSection />
        <Footer />
      </div>
    </ThemeProvider>
  );
}